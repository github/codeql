package org.springframework.beans.factory;

public interface BeanFactory {}
