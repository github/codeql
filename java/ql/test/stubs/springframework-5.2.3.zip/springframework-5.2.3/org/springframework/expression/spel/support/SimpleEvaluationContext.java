
package org.springframework.expression.spel.support;

import org.springframework.expression.*;

public class SimpleEvaluationContext implements EvaluationContext {

    public static Builder forReadWriteDataBinding() { return null; }
    
    public static class Builder {
        public SimpleEvaluationContext build() { return null; }
    }
}