package org.springframework.expression.spel.standard;

import org.springframework.expression.*;

public class SpelExpressionParser implements ExpressionParser {

    public SpelExpressionParser() {}
    
    public Expression parseExpression(String string) { return null; }
}