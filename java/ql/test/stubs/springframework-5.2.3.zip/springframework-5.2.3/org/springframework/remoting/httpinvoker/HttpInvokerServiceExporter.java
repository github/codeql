package org.springframework.remoting.httpinvoker;

public class HttpInvokerServiceExporter extends org.springframework.remoting.rmi.RemoteInvocationSerializingExporter {

    public void setService(Object service) {}

    public void setServiceInterface(Class clazz) {}
}