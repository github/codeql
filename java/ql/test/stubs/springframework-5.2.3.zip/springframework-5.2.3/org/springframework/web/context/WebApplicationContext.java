package org.springframework.web.context;

import org.springframework.context.ApplicationContext;

public interface WebApplicationContext extends ApplicationContext {}
