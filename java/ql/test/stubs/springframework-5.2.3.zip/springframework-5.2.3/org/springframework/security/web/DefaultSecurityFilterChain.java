package org.springframework.security.web;

public final class DefaultSecurityFilterChain implements SecurityFilterChain {}
