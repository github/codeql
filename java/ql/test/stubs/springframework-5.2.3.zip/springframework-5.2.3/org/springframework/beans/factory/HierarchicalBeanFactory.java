package org.springframework.beans.factory;

public interface HierarchicalBeanFactory extends BeanFactory {}
