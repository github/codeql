package org.springframework.security.config.annotation.web.configurers;

import org.springframework.security.config.annotation.web.AbstractRequestMatcherRegistry;

public abstract class AbstractConfigAttributeRequestMatcherRegistry<C> extends
		AbstractRequestMatcherRegistry<C> {}
