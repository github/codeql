package org.springframework.security.config.annotation;

public interface SecurityConfigurer<O, B extends SecurityBuilder<O>> {}
