package org.springframework.expression.spel.support;

import org.springframework.expression.*;

public class StandardEvaluationContext implements EvaluationContext {}