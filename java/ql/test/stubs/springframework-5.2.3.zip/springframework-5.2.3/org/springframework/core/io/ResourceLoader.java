package org.springframework.core.io;

public interface ResourceLoader {}
