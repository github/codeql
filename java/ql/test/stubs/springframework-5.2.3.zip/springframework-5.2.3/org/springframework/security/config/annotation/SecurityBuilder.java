package org.springframework.security.config.annotation;

public interface SecurityBuilder<O> {}
