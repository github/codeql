package org.springframework.security.web;

public interface SecurityFilterChain {}
