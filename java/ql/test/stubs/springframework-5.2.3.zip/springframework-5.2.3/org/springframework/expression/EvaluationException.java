package org.springframework.expression;

public class EvaluationException extends RuntimeException {}