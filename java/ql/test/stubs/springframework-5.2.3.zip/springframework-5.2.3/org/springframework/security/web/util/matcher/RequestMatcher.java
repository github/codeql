package org.springframework.security.web.util.matcher;

public interface RequestMatcher {}
