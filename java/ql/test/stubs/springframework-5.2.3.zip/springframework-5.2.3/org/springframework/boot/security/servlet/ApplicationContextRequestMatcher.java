package org.springframework.boot.security.servlet;

import org.springframework.security.web.util.matcher.RequestMatcher;

public abstract class ApplicationContextRequestMatcher<C> implements RequestMatcher {}
