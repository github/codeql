package org.springframework.web.client;

public abstract interface RequestCallback {
}