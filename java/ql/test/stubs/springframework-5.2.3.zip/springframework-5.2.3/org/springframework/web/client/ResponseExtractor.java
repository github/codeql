package org.springframework.web.client;

public abstract interface ResponseExtractor<K> {
}