package org.springframework.remoting.rmi;

public abstract class RemoteInvocationSerializingExporter {}
