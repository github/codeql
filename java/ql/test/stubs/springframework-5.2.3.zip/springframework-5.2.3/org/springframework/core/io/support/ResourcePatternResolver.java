package org.springframework.core.io.support;

import org.springframework.core.io.ResourceLoader;

public interface ResourcePatternResolver extends ResourceLoader {}
