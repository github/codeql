package org.springframework.http;

public class HttpHeaders implements java.io.Serializable {
}