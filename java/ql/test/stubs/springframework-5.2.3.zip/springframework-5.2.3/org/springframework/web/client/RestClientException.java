package org.springframework.web.client;

public class RestClientException extends Exception {

    private static final long serialVersionUID = -4084444984163796577L;

    public RestClientException(java.lang.String msg) {
    }

    public RestClientException(java.lang.String msg, java.lang.Throwable ex) {
    }
}