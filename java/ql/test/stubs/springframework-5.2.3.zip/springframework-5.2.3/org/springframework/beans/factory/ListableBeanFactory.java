package org.springframework.beans.factory;

public interface ListableBeanFactory extends BeanFactory {}
