package org.springframework.context;

public interface MessageSource {}
