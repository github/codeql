package org.springframework.core.env;

public interface EnvironmentCapable {}
